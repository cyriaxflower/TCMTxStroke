// ann net data file --> load into memory --> send PTR & call me
// 原始的 PureBasic 神經細胞的值被限制在正整數 0 至 99 之間 (8-bit 有號數)
// 原始的 PureBasic 神經細胞的神經鍵值被限制在整數 -128 至 +127 之間 (8-bit 有號數)
// 原始的 PureBasic 為了縮小檔案, 每一個神經鍵值僅用 1 byte 儲存 (8-bit 有號數), 在此須轉成 int (32-bit 有號數) 方便 32/64 位元處理器運算

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const char sCRLF[3] = { 13, 10, 0 };

struct my_message { // 訊息儲存架構
	int  n_max_chars;	// 最長的一行裡, 有幾個英文字 (決定訊息框的寬度)
	int  n_lines;		// 實際訊息有幾行 (每則訊息上限 8 行)
	char *str[8];		// 實際訊息儲存在此 (字串指標)
};

struct  my_message  *my_mesg;	// 訊息陣列 (msg_count 為其數量)
int	group_score[6];		// 六大證型目前得到幾分
int	msg_max = 0;		// 訊息字串數上限, 範圍: 0 至 ??
int	msg_count = 0;		// 訊息字串數, 範圍: 0 至 255  (目前固定為 32)
int	firing_level = 69;	// 神經細胞啟動值, 範圍: 0 至 99
int	input_count;		// 輸入層神經細胞數 (上限: 256)
int	middle_count;		// 中間層神經細胞數 (上限: 512)
int	output_count;		// 輸出層神經細胞數 (上限: 256)
int	cells_input[256];	// 輸入層神經細胞陣列 (上限: 256)
int	cells_middle[512];	// 中間層神經細胞陣列 (上限: 512)
int	cells_output[256];	// 輸出層神經細胞陣列 (上限: 256)
int	net_upper[256][512];	// 輸入層 --> 中間層 神經鍵值 (加權值)
int	net_lower[512][256];	// 中間層 --> 輸出層 神經鍵值 (加權值)
// -------
int  Find_CR(char *p, int loc);	// 從 p[loc] 處開始找換行字元 CR (13)
char *get_msg_str(int msg_id);
void load_full_data(char *ptr);
void load_data(char *ptr);
void run_once(void);
// -------
char *fname = "AN100100.BIN";
int f_len;
char *base_ptr;
int main(void)
{
char	*ptr;
FILE	*fhnd;
int	i, len;

if (! my_mesg) {
	my_mesg = malloc(65536);
	msg_max = 65536 / sizeof(struct my_message);
	}
ptr = malloc(131072);		base_ptr = ptr;
fhnd = fopen(fname, "rb");
fseek(fhnd, 0, 2);
len = ftell(fhnd);
fseek(fhnd, 0, 0);
len = fread(ptr, 1, len, fhnd);
fclose(fhnd);		f_len = len;
printf("read %d bytes from %s OK. 檔案開頭標記 --> %s\n", len, fname, ptr);
load_data(ptr);
printf("將要執行 run_once() !\n");
// 清除三層神經細胞為 0
for (i = 0; i < 256; i ++) {
	cells_input[i] = 0;
	cells_output[i] = 0;
	}
for (i = 0; i < 512; i ++) cells_middle[i] = 0;

// 按照 ANNxxxxxx 來填分數測試 !
group_score[0] = 90;
group_score[1] = 0;
group_score[2] = 0;
group_score[3] = 90;
group_score[4] = 0;
group_score[5] = 0;

for (i = 0; i < input_count; i ++) cells_input[i] = group_score[i];	// 填入輸入層的值

run_once();

printf("程式順利結束 !");
}

// -------
int Find_CR(char *p, int loc)
{ // 從 p[loc] 處開始找換行字元 CR (13)
while (p[loc]) {
	if (p[loc] == 13) return(loc);		// 找到了 !
	loc ++;
	}
return(0);	// 沒找到
}

// -------
char *get_msg_str(int msg_id)
{
struct my_message	*msg;
char	*ans;
int	i;

if (msg_id >= msg_count) return(NULL);		// 超過上限範圍 !
msg = my_mesg + msg_id;
ans = malloc(0x800);	// 最多取 8 行, 每一行上限 256 字元 (8 * 256 = 0x800)
*ans = 0;
for (i=0;i < msg->n_lines; i ++) { // 最多取 8 行
	strcat(ans, msg->str[i]);	strcat(ans, sCRLF);
	}
return(ans);
}

// -------
void load_full_data(char *ptr)
{ // 直接讀取整個 ann net data file, 程式自動讀取 (ANNData.BIN, 71 Kb)
int *pI;
unsigned char *pB;

ptr = ptr + 128;	// 最開頭的 128 bytes 為文字說明, 略過 !
pI = (int *) ptr;
input_count = *pI;	pI ++;		// 取得輸入層神經細胞數 (上限: 256)
middle_count = *pI;	pI ++;		// 取得中間層神經細胞數 (上限: 512)
output_count = *pI;	pI ++;		// 取得輸出層神經細胞數 (上限: 256)
}

// -------
void load_data(char *ptr)
{ // 直接讀取整個 ann compact net data file (ANN******.BIN), 程式自動讀取
struct my_message	*msg;
int *pI;		// 32-bit PTR
unsigned short *pW;	// 16-bit PTR
unsigned char *pB;	//  8-bit PTR
char *tmp;
int	crloc, i, j, last_cr, max_char_num, part_len, slen;

ptr = ptr + 32;		// 最開頭的 32 bytes 為文字說明, 略過 !
pW = (unsigned short *) ptr;
input_count = *pW;	pW ++;		// 取得輸入層神經細胞數 (上限: 256)
middle_count = *pW;	pW ++;		// 取得中間層神經細胞數 (上限: 512)
output_count = *pW;	pW ++;		// 取得輸出層神經細胞數 (上限: 256)
firing_level = *pW;	pW ++;		// 取得 firing_level 值 (範圍: 0 至 99)
msg_count = *pW;	pW ++;		// 取得訊息字串數 (目前固定為 32)
printf("神經細胞數: 輸入層= %d, 中間層= %d, 輸出層= %d, 閥值= %d, 訊息字串數= %d\n", input_count, middle_count, output_count, firing_level, msg_count);
ptr = ptr + 16; 	// 跳到 檔案位置 48 (0x30)
// ------- 讀取 輸入層 --> 中間層的神經網路加權值 (weights) = (input_count * middle_count) bytes -------
for (i = 0;i < input_count;i ++) {
	for (j = 0;j < middle_count; j ++) {
		net_upper[i][j] = *ptr;
		ptr = ptr + 1;
		} // for: j
	} // for: i
// ------- 讀取 中間層 --> 輸出層的神經網路加權值 (weights) = (middle_count * output_count) bytes -------
for (i = 0;i < middle_count; i ++) {
	for (j = 0;j < output_count; j ++) {
		net_lower[i][j] = *ptr;
		ptr = ptr + 1;
		} // for: j
	} // for: i
printf("訊息擺放的起點 offset = 0x%x bytes\n", ptr - base_ptr);  // return;
// ------- 讀取訊息 -------
msg = my_mesg;
for (i = 0; i < msg_count; i ++) {	// 清除整個訊息儲存架構 (訊息字串數 msg_count 目前固定為 32)
	msg->n_max_chars = 0;	// 最長的一行裡, 有幾個英文字 (決定訊息框的寬度)
	msg->n_lines = 0;	// 實際訊息有幾行 (每則訊息上限 8 行)
	for (j = 0; j < 8;j ++) {
		if (! msg->str[j]) {
			msg->str[j] = malloc(256);	// 預借 256 bytes 給字串 (顯示用)
			memset(msg->str[j], 0, 256);	// 預先清除
			}
		}
	last_cr = 0;
	max_char_num = 0;
	pW = (unsigned short *) ptr;	ptr = ptr + 2;
	slen = *pW;	// slen = 此為字串實佔長度
	// printf("slen = %d\n", slen); 
	tmp = ptr;	// 記住此開頭位置
	if (slen > 0) {	// 有訊息內容
		// printf("%d: %s\n", i, tmp); 
		ptr = ptr + slen;	// 讓 ptr 指到下一字串開頭
		for (j = 0; j < 8;j ++) { // 最大掃描紀錄 8 行 (成為單一訊息)
			crloc = Find_CR(tmp, last_cr + 1);
			if (crloc > 0) {  // 有找到 chr(13) = CR 換行分割標記
				// printf("j = %d, crloc = %d\n", j, crloc);
				part_len = crloc - last_cr;	// 此小段字串的長度
				strncpy(msg->str[j], tmp + last_cr + 1, part_len);
				if (max_char_num < part_len) max_char_num = part_len;
				last_cr = crloc;
				}
			else	{ // 沒有找到 chr(13) = CR 換行分割標記
				// printf("j = %d, slen = %d\n", j, slen);
				if (max_char_num == 0) max_char_num = slen;	// 僅剩單行訊息
				msg->n_lines = j + 1;			// 更新此訊息實際行數 (最後一行可能是空的 !)
				msg->n_max_chars = max_char_num;	// 更新此訊息最長的字串小段長度
				break;	// 已經沒有 CR 換行分割標記, 提前結束 (for j)
				}
			} // for: j
		} // if: slen
	printf("訊息 %d: 實際行數= %d, 最長的字串小段長度= %d bytes.\n", i, msg->n_lines, msg->n_max_chars);
	msg ++;		// 繼續檢查下一訊息
	} // for: i
printf("成功載入類神經網路資料 !   Final ofs = 0x%x (處理了 %d bytes)\n", ptr - base_ptr, ptr - base_ptr);
}
// -------
void run_once(void)
{
int	i, j;

// ------- 檢查輸入層神經細胞 --------
for (i = 0;i < input_count; i ++) { // 從輸入層神經細胞開始檢查
	if (cells_input[i] > firing_level) { // 大於此閥值, 代表輸入層神經細胞活化 !
		for (j = 0; j < middle_count; j ++) { // 往中間層處理
			cells_middle[j] = cells_middle[j] + net_upper[i][j];	// 輸入層神經細胞有活化, 此時中間層神經細胞可以得到相對應的神經網路加權值 (weight)
			if (cells_middle[j] > 100) cells_middle[j] = 100;	// 防止超過 100 (上限)
			} // for: j
		} // if: cells_input[i]
	} // for: i
// ------- 檢查中間層神經細胞 --------
for (i = 0;i < middle_count;i ++) { // 從中間層神經細胞開始檢查
	if (cells_middle[i] > firing_level) { // 大於此閥值, 代表中間層神經細胞活化 !
		for (j = 0; j < output_count; j ++) { // 往輸出層處理
			cells_output[j] = cells_output[j] + net_lower[i][j];	// 輸入層神經細胞有活化, 此時中間層神經細胞可以得到相對應的神經網路加權值 (weight)
			if (cells_output[j] > 100) cells_output[j] = 100;	// 防止超過 100 (上限)
			} // for: j
		} // if: cells_middle[i]
	} // for: i
// ---- 收集最終結果 (輸出層神經細胞) ----
for (i = 0;i < output_count;i ++) { // 從輸出層神經細胞開始檢查
	printf("輸出層 cell %d = %d\n", i, cells_output[i]);
	if (cells_output[i] > firing_level) { // 大於此閥值, 代表輸出層神經細胞活化 !
		printf("此證型的輸出: %s\n", get_msg_str(6 + i));	// 取得訊息字串 (頭六個字串是六大證型, 故加 6)
		}
	}
}

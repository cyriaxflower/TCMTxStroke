#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <jni.h>
#include <android/log.h>

#define _debug_on_

int  su_main(char *path);
void  cDbg(const char *fmt, ...);
char *get_mystr_lwr(int grp, int ndx);
char *get_str(int type_id, int row);
void hex_dump(void *p, int len);
char *move_after(char *pDst, char *pSrc, int len);		// �� pSrc �b pDst �᭱, �B�����| ! �ݭ˰h�h�� !
int read_4_bytes(char *p, int ofs);
short read_2_bytes(char *p, int ofs);
char *strlwr(char *p);	// �� p �r���ন�p�g
char *strupr(char *p);	// �� p �r���ন�j�g
int trim(char *s);
void *xmemcpy(void *dst, void *src, int len);	// �«������ memcpy() ����Ʒ|����
void *xmemmove(void *dest, void *src, int len);
char *xstrcpy(char *dst, char* src);

char *toSay;
const char *ID_SJC = "SJC debug";
jbyte pWork[2306];		// = 256 + 2048
char  cDbg_text[512];
static char buff[256];		// debug_Say() �M��
static char says[256];		// �ϥΩ� trim();
static char save[512];		// �ϥΩ������g�����x�s��X���G
static char temp2[256];		// �ϥΩ� strlwr(), strupr(), dbf_read_str()

// --------------
int xstrlen(char *s)
{ // �«��������Ʒ|����
int len;

if (!s) return(0);	len = 0;
while(*s) { len ++; s++; }		// cDbg("%s -> xstrlen = %d", s, len);
return(len);
}


void debug_Say(char *s)
{
	xstrcpy(buff, s);
	__android_log_write(ANDROID_LOG_DEBUG, ID_SJC, (const char *) buff);
//__android_log_print(ANDROID_LOG_DEBUG, ID_SJC, "look here t1 = %lX", t1);
}

// �Y�L�X�� %s �̭��٦� format �榡�r��, printf �N�|�����i�w�������G ! �i�令 puts() ���|�h�X�@�Ӵ��� !
void cDbg(const char *fmt, ...)
{ // bug: vsprintf
va_list ap;
int  len;

if (fmt == NULL) return;
cDbg_text[0] = 0;
va_start(ap, fmt);
    vsprintf(cDbg_text, fmt, ap);
va_end(ap);
// __android_log_write(ANDROID_LOG_DEBUG, ID_SJC, (const char *) cDbg_text);
debug_Say(cDbg_text);
}

char * __memmove_chk (char *dest, const char *src, size_t len)  {   return(dest);  }
char * __strcat_chk (char *dest, const char *src)  {  size_t ret;  ret = xstrlen((char *)dest) + xstrlen((char *)src);  return((char *) ret);  }
// -------------- // for API 10
char * __strcpy_chk (char *dest, const char *src, size_t destlen)
{
	sprintf("--- TCMT: don't call me: _strcpy_chk( dest=%x, src=%x, destlen= %d ) ---", dest, src, destlen);
	debug_Say(buff);
	return(dest);
}
// -------------- // for API 10
size_t __strlen_chk(const char* str, size_t __n) // __INTRODUCED_IN(17);
{
size_t ret;

	if (str == NULL) { debug_Say("TCMT #81 strlen_chk got NULL ptr !");  return(0); }
	ret = xstrlen((char *)str);
	if (ret > __n) debug_Say("TCMT #82 *** libc: strlen read overflow detected ***");
	return(ret);
}
// -------------- // for API 10
char *__memcpy_chk (void *dest, const void *src, size_t len, size_t dstlen)
{
	// if (api_level > 20) return(dest);	// API 21 �H�W, �I�s����Ʒ|���� !!
	if (dstlen < len) {  cDbg("__memcpy_chk failed (dstlen = %d < len = %).", dstlen, len);  return(dest); }
	// cDbg("--- pls don't call me: __memcpy_chk( dest=%x, src=%x, len=%d, destlen= %d ) ---", dest, src, len, dstlen);
	return memcpy(dest, src, len);
} 
// -------------- // for API 10 (& �غӪ��襭�O)
int __vsprintf_chk(char* dest, int flags,  size_t dest_len_from_compiler, const char* format, va_list va) {
 // �ӳ·� ! �Ȥ��B�z, �������]�ѼƳ��X�� !	__android_log_write(ANDROID_LOG_DEBUG, ID_SJC, (const char *) "__vsprintf_chk");
  return (1); // result;  // ��^�t�Ȭ����~, 0 < result < n �����T
}

char *xstrcpy(char *dst, char* src) {
	while (*src) { *dst = *src;  dst ++;  src ++; 	}
	*dst = 0;	return(dst);
}

char *xstrcat(char *dst, char* to_add) {
int  slen;

	if (! dst) return(NULL);
	slen = xstrlen(dst);	xstrcpy(dst + slen, to_add);	return(dst);
}

jint
Java_com_sjc_txstroke_MainActivity_func1( JNIEnv* env, jobject thiz, long id_obj, long cmd, jbyteArray buf )
{
long	rtv;

	rtv = -1;	// �Ǧ^��ƪ��� (0 �Υ��Ȭ����T), -1=�����~
	if (cmd == 0) return(rtv);
	if (buf == NULL) debug_Say("** NULL buffer was found **");
	switch (cmd) {
		case 1:
			(*env)->GetByteArrayRegion(env, buf, 0, 512, (jbyte *) pWork);	// ���� buf[] �� p[], �̰��e�\Ū�� 512 bytes
			// debug_Say("#123 arg = ");  debug_Say(p);	
			su_main((char*) &pWork[0]);		xmemmove(save, pWork + 256, 2048);	rtv = 0;	break;
		case 2:	
			(*env)->SetByteArrayRegion(env, buf, 0, 2048, (jbyte *) save);	// ���� save[2048] �� buf[]
			rtv = 2048;	break;
		default: debug_Say("cmd too large (> 2) !");	break;
	}
    return rtv;
}

jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
    JNIEnv* env = NULL;
    jint result = -1;

    if ((*vm)->GetEnv(vm, (void**) &env, JNI_VERSION_1_4) != JNI_OK) {
	debug_Say("ERROR: GetEnv failed\n");
        return result;
    }
    debug_Say("TCMT JNI is OK !\n(TCMT: Traditional Chinese Medicine Therapy)");
//    assert(env != NULL);
    /* success -- return valid version number */
    return JNI_VERSION_1_4;
}

int read_4_bytes(char *p, int ofs)
{
int *pl;

pl = (int *) (p + ofs);
return(*pl);
}

short read_2_bytes(char *p, int ofs)
{
short *pi;

pi = (short *) (p + ofs);
return(*pi);
}

void prt_8bit(char *s, char v)
{
char c;

c = (v >> 4) & 15;	if (c > 9) c = c + 7;
s[0] = c + 48;
c = v & 15;	if (c > 9) c = c + 7;
s[1] = c + 48;
}

void prt_32bit(char *s, size_t v)
{
unsigned int  v1;

v1 = (v >> 24) & 255;	prt_8bit(s, v1);	s += 2;
v1 = (v >> 16) & 255;	prt_8bit(s, v1);	s += 2;
v1 = (v >> 8) & 255;	prt_8bit(s, v1);	s += 2;
v1 = v  & 255;		prt_8bit(s, v1);	s += 2;
}

void hex_dump(void *p, int len)
{ // only for 32-bit !
int		i, j;
char	s[80], s1[16], *pb;

	pb = p;		if (p == NULL) { debug_Say("HexDump: NULL pointer !!");  return; }
	if (len < 1) { debug_Say("HexDump: length < 1");  return; }
	while (len > 0) {
		memset(s, 32, 60);		prt_32bit(s1, (size_t) pb); 	xmemmove(s, s1, 8);	s1[8] = '-';	// sprintf(s1, "%08zx", (size_t) pb);
		for (i = 0, j = 10;i < 16;i ++, j += 3) { prt_8bit(s1, pb[i]);  xmemmove(s+j, s1, 2); }	// sprintf(s1, "%02X", pb[i]);
		for (i = 0;i < 16;i ++) s[i+60] = (pb[i] > 31) ? pb[i] : '.';		s[76] = 0;
		debug_Say(s);	len -= 16;		pb += 16;
	}
}

char *strlwr(char *p)
{	// �� p �r���ন�p�g (�p�ߤ���r�|�X��)
char	*p2;

	if (p == NULL) return(NULL);
	p2 = temp2;
	while (*p) {
		if ((*p > 64) && (*p < 91)) *p2 = *p + 32;
		else *p2 = *p;
		p ++;	p2 ++;
	}
	*p2 = 0;	return(temp2);
}

char *strupr(char *p)
{	// �� p �r���ন�j�g (�p�ߤ���r�|�X��)
char	*p2;

	if (p == NULL) return(NULL);
	p2 = temp2;
	while (*p) {
		if ((*p > 96) && (*p < 123)) *p2 = *p - 32;
		else *p2 = *p;
		p ++;	p2 ++;
	}
	*p2 = 0;	return(temp2);
}

int trim(char *s)
{
int		len;
char	c, spc;

	len = xstrlen(s) - 1;
	if (len < 0) return 0;		// �L����r�� !
	do	{	// �R����誺�ťզr��
		c = s[len];		spc = 0;
		if ((c == 32) || (c == 9))  { spc = 1;  s[len] = 0;	}	// �O SPACE, TAB �h���N�� 0
		if ((c == 10) || (c == 13)) { spc = 1;  s[len] = 0;	}	// �O CR, LF �h���N�� 0
		len --;
	} while (spc);
	do	{	// �����e�誺�ťզr��
		c = *s++;
		if ((c == 32) || (c == 9)) continue;	// �O SPACE, TAB, CR, LF �h����
		if ((c == 10) || (c == 13)) continue;	// �O CR, LF �h����
		s --;	xstrcpy(says, s);	xstrcpy(s, says);	c = 0;
	} while (c != 0);	// ** bug: trim ��, �e�褴���@�Ӫť� !
	return(xstrlen(s));
}
// --------------
char *move_after(char *pDst, char *pSrc, int len)
{ // �� pSrc �b pDst �᭱, �B�����| ! �ݭ˰h�h�� !
if (len > 0) {
	len --;		pDst += len;	pSrc += len;
	do	{
		*pDst = *pSrc;	pDst --;	pSrc --;	len --;
		} while(len > 0);
	}
return(pDst);
}
// -------------
void *xmemcpy(void *dst, void *src, int len)
{ // �«������ memcpy() ����Ʒ|����
char *pd, *ps;
int i;

if (!dst) return(dst);		// debug_Say("265");  vHex("dst = ", dst);  vHex("src = ", src);  vHex("len = ", (void *) (size_t) len);
if (!src) return(dst);
if (len < 1) return(dst);
pd = (char *) dst;	ps = (char *) src;
for (i=0;i<len;i++) {  *pd=*ps;  pd++;  ps++;  }
return(dst);
}
// -------------
void *xmemmove(void *dest, void *src, int len)
{
if (len < 1) return(dest);		// cDbg("xmemmove: dest= $%s, src= $%s, len= %x", toStr(dest), toStr(src), len);  
if ((!dest) || (!src)) return(dest);
if (dest == src) {  cDbg("xmemmove: Error, dest & src overlapped !");  return(dest);  }		// no need to move !
if ((size_t) dest > (size_t) src) { // src--dest--(+len) �p�G dest ���b src ����ݤ���, �h�ݭ˰h�h�� !
	if ((size_t) dest < ((size_t) src + (size_t) len)) {
		move_after(dest, src, len);		// �˰h�h�� !
		return(dest);
		}
	}
if (((size_t) dest > (size_t) src) && ((size_t) dest < ((size_t) src) + (size_t) len)) move_after(dest, src, len);
return(xmemcpy(dest, src, len));
}

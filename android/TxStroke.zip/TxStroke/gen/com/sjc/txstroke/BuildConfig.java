/** Automatically generated file. DO NOT MODIFY */
package com.sjc.txstroke;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
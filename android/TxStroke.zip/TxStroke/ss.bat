@echo off
c:
cd c:\andr\txstroke\jni
rem call D:\tools\android-ndk-r22b\ndk-build -B V=1 NDK_LOG=1

@rem 	I:\android-ndk-r21\ndk-build  K:\Android\sdk\ndk-bundle\ndk-build

set NDK_PLATFORMS_ROOT=I:\android-ndk-r21\platforms
 call I:\android-ndk-r21\ndk-build

cd ..

@rem copy /y obj\local\x86_64\*.* libs\x86_64\

adb push libs\x86\libtcmt.so  /data/data/com.sjc.txstroke/lib

@rem -- adb push libs\x86_64\libtcmt.so   /data/app/com.sjc.oneapp-1/lib/x86_64
@rem -- adb push libs\x86_64\libtcmt.so   /data/app/com.sjc.oneapp-4/lib/x86_64

@rem -- adb push libs\armeabi-v7a\libtcmt.so  /data/data/com.sjc.oneapp/lib/
